﻿namespace $safeprojectname$.Controls {
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for StyledFlowDocument.xaml
    /// </summary>
    public partial class StyledFlowDocument : UserControl {
        public StyledFlowDocument() {
            this.InitializeComponent();
        }
    }
}