﻿namespace $safeprojectname$.Controls {
    using System.Windows.Controls;

    using $safeprojectname$.ViewModels;

    /// <summary>
    /// Interaction logic for ChatCodes.xaml
    /// </summary>
    public partial class ChatCodes : UserControl {
        public ChatCodes() {
            this.InitializeComponent();

            Instance = this;

            this.DataContext = ChatCodesViewModel.Instance;
        }

        public static ChatCodes Instance { get; set; }
    }
}