﻿namespace $safeprojectname$.Controls {
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for SettingsTabItem.xaml
    /// </summary>
    public partial class SettingsTabItem : UserControl {
        public SettingsTabItem() {
            this.InitializeComponent();
        }
    }
}