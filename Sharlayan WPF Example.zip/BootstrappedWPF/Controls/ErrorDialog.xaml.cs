﻿namespace $safeprojectname$.Controls {
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for ErrorDialog.xaml
    /// </summary>
    public partial class ErrorDialog : UserControl {
        public ErrorDialog() {
            this.InitializeComponent();
        }
    }
}