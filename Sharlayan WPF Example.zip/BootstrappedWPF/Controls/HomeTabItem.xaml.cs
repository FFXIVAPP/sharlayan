﻿namespace $safeprojectname$.Controls {
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for HomeTabItem.xaml
    /// </summary>
    public partial class HomeTabItem : UserControl {
        public HomeTabItem() {
            this.InitializeComponent();
        }
    }
}