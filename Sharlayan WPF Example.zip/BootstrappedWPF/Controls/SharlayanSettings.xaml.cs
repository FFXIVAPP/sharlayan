﻿namespace $safeprojectname$.Controls {
    using System.Windows.Controls;

    using $safeprojectname$.ViewModels;

    /// <summary>
    /// Interaction logic for Settings.xaml
    /// </summary>
    public partial class SharlayanSettings : UserControl {
        public SharlayanSettings() {
            this.InitializeComponent();

            this.DataContext = SharlayanSettingsViewModel.Instance;
        }
    }
}