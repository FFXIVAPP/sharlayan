﻿namespace $safeprojectname$.Controls {
    using System.Windows.Controls;

    using $safeprojectname$.ViewModels;

    /// <summary>
    /// Interaction logic for PaletteSelector.xaml
    /// </summary>
    public partial class PaletteSelector : UserControl {
        public PaletteSelector() {
            this.InitializeComponent();

            this.DataContext = PaletteSelectorViewModel.Instance;
        }
    }
}