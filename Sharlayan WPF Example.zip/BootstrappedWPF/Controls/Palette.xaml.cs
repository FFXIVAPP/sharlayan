﻿namespace $safeprojectname$.Controls {
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for Palette.xaml
    /// </summary>
    public partial class Palette : UserControl {
        public Palette() {
            this.InitializeComponent();
        }
    }
}