﻿namespace $safeprojectname$.ViewModels {
    public class ErrorDialogViewModel {
        public string Message { get; set; }
    }
}