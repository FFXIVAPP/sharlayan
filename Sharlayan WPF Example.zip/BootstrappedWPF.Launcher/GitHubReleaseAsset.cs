﻿namespace $safeprojectname$ {
    public class GitHubReleaseAsset {
        public string browser_download_url { get; set; }
        public string name { get; set; }
    }
}